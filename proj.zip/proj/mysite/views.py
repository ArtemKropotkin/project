from django.shortcuts import render

# Create your views here.

from django.shortcuts import render
from django.template import loader

from django.http import HttpResponse
from django import template


def index(request):
        context ={}
        html_file = loader.get_template( 'index.html' )
        return HttpResponse(html_file.render(context, request))    

def page1(request):
#        requested_html = request.path.split('/')[-1]
        context ={
            "table1":[
                ["Ноутбук", 20000, "i5 32Gb",], 
                ["Телефон", 6000, "2Gb"], 
                ["Наушники", 1000, "Sony"]
            ]
        }
        html_file = loader.get_template( 'table.html' )
        return HttpResponse(html_file.render(context, request))    

def page2(request):
#        requested_html = request.path.split('/')[-1]
        context ={
            "table1":[
                ["Ноутбук", 30000, "i7 64Gb",], 
                ["Телефон", 12000, "4Gb"], 
                ["Наушники", 2000, "JBL"],
                ["Наушники", 600, "Oclick"]
            ]
        }
        html_file = loader.get_template( 'table.html' )
        return HttpResponse(html_file.render(context, request))    

def page3(request):
#        requested_html = request.path.split('/')[-1]
        context ={
            "table1":[
                ["Ноутбук", 40000, "i9 64Gb Gaming",], 
                ["Телефон", 26000, "8Gb"], 
                ["Наушники", 4000, "Anker"],
                ["Клавиатура", 1000, "DNS"]
            ]
        }
        html_file = loader.get_template( 'table.html' )
        return HttpResponse(html_file.render(context, request))    
